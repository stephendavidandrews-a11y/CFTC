import React, { useState, useEffect } from 'react';
import { Routes, Route, useLocation, useNavigate } from 'react-router-dom';
import { Pulse } from './components/UI';
import Summary from './pages/Summary';
import EOTracker from './pages/EOTracker';
import Team from './pages/Team';
import Pipeline from './pages/Pipeline';
import Intelligence from './pages/Intelligence';
import CommentsDashboard from './pages/CommentsDashboard';
import CommentList from './pages/CommentList';
import CommentDetail from './pages/CommentDetail';
import Processing from './pages/Processing';
import NewDocket from './pages/NewDocket';
import Placeholder from './pages/Placeholder';

const SECTIONS = [
  { id: '/', label: 'Executive Summary', icon: '◫' },
  { id: '/eo', label: 'EO Tracker', icon: '⚑', badge: '4', badgeClass: 'red' },
  { id: '/team', label: 'Team', icon: '⊡' },
  { id: '/pipeline', label: 'Pipeline', icon: '▤' },
  { id: '/interagency', label: 'Interagency', icon: '⬡' },
  { id: '/research', label: 'Research', icon: '⊞' },
  { id: '/comments', label: 'Comments', icon: '✉', badge: '819', badgeClass: 'blue' },
  { id: '/intelligence', label: 'Intelligence', icon: '◉', pulse: true },
  { id: '/reports', label: 'Reports', icon: '⊟' },
];

export default function App() {
  const location = useLocation();
  const navigate = useNavigate();
  const [time, setTime] = useState(new Date());

  useEffect(() => {
    const t = setInterval(() => setTime(new Date()), 60000);
    return () => clearInterval(t);
  }, []);

  const isActive = (path) => {
    if (path === '/') return location.pathname === '/';
    return location.pathname.startsWith(path);
  };

  return (
    <div className="app-layout">
      {/* Sidebar */}
      <aside className="sidebar">
        <div className="sidebar-header">
          <div className="sidebar-brand">
            <div className="sidebar-logo">C</div>
            <div>
              <div className="sidebar-title">Command Center</div>
              <div className="sidebar-subtitle">CFTC · Office of GC</div>
            </div>
          </div>
        </div>

        <nav className="sidebar-nav">
          {SECTIONS.map(s => (
            <button
              key={s.id}
              className={`nav-btn ${isActive(s.id) ? 'active' : ''}`}
              onClick={() => navigate(s.id)}
            >
              <span className="nav-icon">{s.icon}</span>
              <span className="nav-label">{s.label}</span>
              {s.badge && <span className={`nav-badge ${s.badgeClass}`}>{s.badge}</span>}
              {s.pulse && <Pulse color="#22c55e" />}
            </button>
          ))}
        </nav>

        <div className="sidebar-footer">
          <div className="user-info">
            <div className="user-avatar">SA</div>
            <div>
              <div className="user-name">S. Andrews</div>
              <div className="user-role">Deputy GC, Regulation</div>
            </div>
          </div>
        </div>
      </aside>

      {/* Main */}
      <main className="main-content">
        <Routes>
          <Route path="/" element={<Summary />} />
          <Route path="/eo" element={<EOTracker />} />
          <Route path="/team" element={<Team />} />
          <Route path="/pipeline" element={<Pipeline />} />
          <Route path="/comments" element={<CommentsDashboard />} />
          <Route path="/comments/browse" element={<CommentList />} />
          <Route path="/comments/detail/:documentId" element={<CommentDetail />} />
          <Route path="/comments/processing" element={<Processing />} />
          <Route path="/comments/new-docket" element={<NewDocket />} />
          <Route path="/intelligence" element={<Intelligence />} />
          <Route path="/interagency" element={
            <Placeholder title="Interagency" description="Project Crypto workstreams, PWG deliverables, bilateral coordination." icon="⬡" />
          } />
          <Route path="/research" element={
            <Placeholder title="Research" description="Full-text search across the regulatory database. Loper Bright vulnerability scanner." icon="⊞" />
          } />
          <Route path="/reports" element={
            <Placeholder title="Reports" description="Weekly status generator, meeting prep builder, briefing templates." icon="⊟" />
          } />
        </Routes>
      </main>
    </div>
  );
}
