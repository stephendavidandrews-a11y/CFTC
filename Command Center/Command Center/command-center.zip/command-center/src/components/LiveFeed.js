import React, { useState, useEffect } from 'react';
import { Pulse, FEED_COLORS } from './UI';

// Placeholder data — will be replaced by API calls to your feed service
const PLACEHOLDER_FEED = [
  { time: '2 min ago', type: 'tweet', source: '@CFTCChairman', text: 'Excited to announce progress on our digital assets framework. The PWG report is ahead of schedule.', icon: '𝕏' },
  { time: '18 min ago', type: 'news', source: 'Reuters', text: 'SEC and CFTC to hold joint hearing on crypto custody rules next month', icon: '◆' },
  { time: '34 min ago', type: 'fr', source: 'Federal Register', text: 'CFTC-2025-0005: Digital Asset Clearing Amendments — 12 new comments received', icon: '⬢' },
  { time: '1 hr ago', type: 'tweet', source: '@SenLummis', text: 'Bipartisan stablecoin bill moves to markup next week. Strong support from Treasury and CFTC.', icon: '𝕏' },
  { time: '1.5 hr ago', type: 'news', source: 'CoinDesk', text: 'Kalshi seeks to expand political event contracts after favorable CFTC guidance', icon: '◆' },
  { time: '2 hr ago', type: 'regulatory', source: 'SEC', text: 'Staff Accounting Bulletin 122 rescission — crypto custody treatment revised', icon: '⊕' },
  { time: '3 hr ago', type: 'tweet', source: '@HesterPeirce', text: 'Tokenized collateral is the next frontier. Looking forward to CFTC\'s proposed framework.', icon: '𝕏' },
  { time: '4 hr ago', type: 'fr', source: 'Federal Register', text: 'OCC issues interpretive letter on national bank authority for stablecoin reserves', icon: '⬢' },
  { time: '5 hr ago', type: 'news', source: 'Bloomberg', text: 'Trump crypto working group targets July deadline for comprehensive regulatory framework', icon: '◆' },
  { time: '6 hr ago', type: 'regulatory', source: 'Treasury', text: 'FinCEN proposed rule on DeFi broker definition — comment period opens March 1', icon: '⊕' },
];

export default function LiveFeed({ items }) {
  const feed = items && items.length > 0 ? items : PLACEHOLDER_FEED;
  const [flash, setFlash] = useState(null);

  useEffect(() => {
    const interval = setInterval(() => {
      setFlash(0);
      setTimeout(() => setFlash(null), 2000);
    }, 15000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="card" style={{ height: '100%', display: 'flex', flexDirection: 'column' }}>
      <div className="card-header">
        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <Pulse color="#22c55e" />
          <span className="card-title">Live Intelligence Feed</span>
        </div>
        <span className="card-subtitle">Auto-updating</span>
      </div>
      <div style={{ flex: 1, overflowY: 'auto' }}>
        {feed.map((item, i) => {
          const fc = FEED_COLORS[item.type] || FEED_COLORS.news;
          const isFlash = flash === i;
          return (
            <div
              key={i}
              className={`feed-item ${fc.cls}`}
              style={isFlash ? {
                borderLeftColor: fc.accent,
                background: `${fc.accent}12`,
              } : undefined}
            >
              <div className="feed-header">
                <span style={{ fontSize: 12, color: fc.accent, fontWeight: 700 }}>{item.icon}</span>
                <span className="feed-source" style={{ color: fc.accent }}>{item.source}</span>
                <span className="feed-time">{item.time}</span>
              </div>
              <div className="feed-text">{item.text}</div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
