import React from 'react';

export function Pulse({ color = '#22c55e' }) {
  return (
    <span className="pulse">
      <span className="pulse-ring" style={{ background: color }} />
      <span className="pulse-dot" style={{ background: color }} />
    </span>
  );
}

export function Badge({ bg, text, label }) {
  return (
    <span className="badge" style={{ background: bg, color: text, border: `1px solid ${text}22` }}>
      {label}
    </span>
  );
}

export function StatCard({ value, label, accent, pulse: showPulse }) {
  const cls = accent === '#3b82f6' ? 'blue' : accent === '#ef4444' ? 'red' : accent === '#a78bfa' ? 'purple' : 'green';
  return (
    <div className={`stat-card ${cls}`}>
      <div className="stat-value">
        {value}
        {showPulse && <Pulse color={accent} />}
      </div>
      <div className="stat-label">{label}</div>
    </div>
  );
}

export const STATUS_COLORS = {
  in_progress: { bg: '#1e3a5f', text: '#60a5fa', label: 'In Progress' },
  completed: { bg: '#14532d', text: '#4ade80', label: 'Completed' },
  superseded: { bg: '#422006', text: '#fbbf24', label: 'Superseded' },
  not_started: { bg: '#1f2937', text: '#9ca3af', label: 'Not Started' },
};

export const STAGE_COLORS = {
  drafting: { bg: '#1f2937', text: '#9ca3af', label: 'Drafting', accent: '#6b7280' },
  proposed: { bg: '#172554', text: '#60a5fa', label: 'Proposed Rule', accent: '#3b82f6' },
  comment: { bg: '#422006', text: '#fbbf24', label: 'Comment Period', accent: '#f59e0b' },
  final: { bg: '#14532d', text: '#4ade80', label: 'Final Rule', accent: '#22c55e' },
};

export const FEED_COLORS = {
  tweet: { accent: '#1d9bf0', cls: 'tweet' },
  news: { accent: '#f59e0b', cls: 'news' },
  fr: { accent: '#a78bfa', cls: 'fr' },
  regulatory: { accent: '#34d399', cls: 'regulatory' },
};
