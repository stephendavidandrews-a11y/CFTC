const API_BASE = process.env.REACT_APP_API_URL || '/api/v1';

async function fetchJSON(path, opts = {}) {
  const res = await fetch(`${API_BASE}${path}`, {
    headers: { 'Content-Type': 'application/json', ...opts.headers },
    ...opts,
    body: opts.body ? JSON.stringify(opts.body) : undefined,
  });
  if (!res.ok) throw new Error(`API ${res.status}: ${res.statusText}`);
  return res.json();
}

export const api = {
  // Comment system endpoints (existing)
  getRules: (params = {}) => {
    const qs = Object.entries(params).filter(([,v]) => v).map(([k,v]) => `${k}=${encodeURIComponent(v)}`).join('&');
    return fetchJSON(`/rules${qs ? '?' + qs : ''}`);
  },
  getRule: (docket) => fetchJSON(`/rules/${encodeURIComponent(docket)}`),
  getComments: (params = {}) => {
    const qs = new URLSearchParams(params).toString();
    return fetchJSON(`/comments?${qs}`);
  },
  getComment: (docId) => fetchJSON(`/comments/${encodeURIComponent(docId)}`),
  getStats: (docket) => fetchJSON(`/comments/stats/${encodeURIComponent(docket)}`),
  getNarrative: (docket) => fetchJSON(`/comments/narrative/${encodeURIComponent(docket)}`),
  detectFormLetters: (docket) =>
    fetchJSON(`/comments/detect-form-letters?docket_number=${encodeURIComponent(docket)}`, { method: 'POST' }),
  aiTier: (docket, batchSize = 50) =>
    fetchJSON(`/comments/ai-tier?docket_number=${encodeURIComponent(docket)}&batch_size=${batchSize}`, { method: 'POST' }),
  aiSummarize: (docket, tier = null, batchSize = 50) => {
    let url = `/comments/ai-summarize?docket_number=${encodeURIComponent(docket)}&batch_size=${batchSize}`;
    if (tier) url += `&tier=${tier}`;
    return fetchJSON(url, { method: 'POST' });
  },
  getRulemakings: (year) => fetchJSON(`/rulemakings/${year}`),
  ingestDocket: (releaseId) => fetchJSON(`/ingest/${releaseId}`, { method: 'POST' }),
  exportBriefing: (docket) => `${API_BASE}/comments/export-briefing/${encodeURIComponent(docket)}`,
  exportPdfs: (docket) => `${API_BASE}/comments/export-pdfs/${encodeURIComponent(docket)}`,
  getTier1Orgs: () => fetchJSON('/tier1-orgs'),

  // Command center endpoints (new — will connect to future APIs)
  getFeed: () => fetchJSON('/feed').catch(() => ({ items: [] })),
  getDeadlines: () => fetchJSON('/deadlines').catch(() => ({ items: [] })),
  getTeamWorkload: () => fetchJSON('/team/workload').catch(() => ({ members: [] })),
  getEOStatus: () => fetchJSON('/eo/status').catch(() => ({ orders: [] })),
};
