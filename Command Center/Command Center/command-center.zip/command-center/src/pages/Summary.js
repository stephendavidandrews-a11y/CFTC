import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { StatCard, Badge, STAGE_COLORS } from '../components/UI';
import LiveFeed from '../components/LiveFeed';

// Placeholder data — these will come from API endpoints you build later
const DEADLINES = [
  { date: '2025-03-01', item: 'PWG Report: Stablecoin Regulatory Framework', owner: 'Interagency', status: 'danger' },
  { date: '2025-03-10', item: 'EO 14178 — 60-Day Regulatory Gap Analysis', owner: 'S. Andrews', status: 'danger' },
  { date: '2025-03-15', item: 'Reg AT Modernization — Final Rule', owner: 'M. Williams', status: 'warning' },
  { date: '2025-04-01', item: 'Comment Period Close: Event Contracts', owner: 'D. Thompson', status: 'ok' },
  { date: '2025-04-15', item: 'EO 14178 — Proposed Token Classification Framework', owner: 'S. Chen', status: 'ok' },
  { date: '2025-05-01', item: 'EO 14192 — Deregulation Cost-Benefit Report', owner: 'J. Park', status: 'ok' },
];

const TEAM_PREVIEW = [
  { name: 'Sarah Chen', role: 'Assistant General Counsel', active: 3, overdue: 1 },
  { name: 'Marcus Williams', role: 'Senior Counsel', active: 4, overdue: 0 },
  { name: 'Jennifer Park', role: 'Senior Counsel', active: 2, overdue: 0 },
  { name: 'David Thompson', role: 'Attorney-Adviser', active: 3, overdue: 1 },
  { name: 'Ana Martinez', role: 'Attorney-Adviser', active: 3, overdue: 2 },
];

const PIPELINE = [
  { title: 'Event Contracts & Enumerated Activities', stage: 'comment', docket: 'CFTC-2024-0007', comments: 819, deadline: '2025-04-30' },
  { title: 'Tokenized Collateral Framework', stage: 'proposed', docket: 'CFTC-2025-0002', comments: 0, deadline: '2025-06-15' },
  { title: 'DeFi Safe Harbor Pilot', stage: 'drafting', docket: null, comments: 0, deadline: '2025-08-01' },
  { title: 'Digital Asset Clearing Amendments', stage: 'proposed', docket: 'CFTC-2025-0005', comments: 42, deadline: '2025-05-20' },
  { title: 'Reg AT Modernization', stage: 'final', docket: 'CFTC-2024-0012', comments: 156, deadline: '2025-03-15' },
];

export default function Summary() {
  const navigate = useNavigate();
  const [now, setNow] = useState(new Date());

  useEffect(() => {
    const t = setInterval(() => setNow(new Date()), 1000);
    return () => clearInterval(t);
  }, []);

  const deadlineColor = s => s === 'danger' ? '#ef4444' : s === 'warning' ? '#f59e0b' : '#334155';

  return (
    <div>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 28 }}>
        <div>
          <h2 className="page-title">Executive Summary</h2>
          <p className="page-desc">Office of General Counsel — Regulation Division</p>
        </div>
        <div style={{ textAlign: 'right' }}>
          <div style={{ fontSize: 13, color: '#94a3b8', fontFamily: 'var(--font-mono)' }}>
            {now.toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}
          </div>
          <div style={{ fontSize: 20, color: '#f1f5f9', fontFamily: 'var(--font-mono)', fontWeight: 600, letterSpacing: '0.05em' }}>
            {now.toLocaleTimeString('en-US', { hour12: false })}
          </div>
        </div>
      </div>

      <div className="stat-grid">
        <StatCard value="5" label="Active Executive Orders" accent="#3b82f6" />
        <StatCard value="4" label="Overdue Items" accent="#ef4444" pulse />
        <StatCard value="5" label="Active Rulemakings" accent="#a78bfa" />
        <StatCard value="10" label="Attorneys" accent="#22c55e" />
      </div>

      <div className="grid-2-right">
        <div style={{ display: 'flex', flexDirection: 'column', gap: 20 }}>
          {/* Deadlines */}
          <div className="card">
            <div className="card-header">
              <span className="card-title">Upcoming Deadlines</span>
              <span className="card-subtitle">Next 90 days</span>
            </div>
            {DEADLINES.map((d, i) => (
              <div key={i} className="deadline-row">
                <div className="deadline-dot" style={{ background: deadlineColor(d.status) }} />
                <div className="deadline-date">{d.date}</div>
                <div className="deadline-text">{d.item}</div>
                <div className="deadline-owner">{d.owner}</div>
              </div>
            ))}
          </div>

          {/* Team preview */}
          <div className="card">
            <div className="card-header">
              <span className="card-title">Team Workload</span>
              <button onClick={() => navigate('/team')} style={{
                background: 'none', border: 'none', color: '#60a5fa',
                fontSize: 11, cursor: 'pointer', fontFamily: 'var(--font-sans)',
              }}>View all →</button>
            </div>
            {TEAM_PREVIEW.map((t, i) => (
              <div key={i} style={{
                display: 'flex', alignItems: 'center', gap: 12, padding: '9px 0',
                borderBottom: '1px solid var(--border)', fontSize: 13,
              }}>
                <div style={{
                  width: 30, height: 30, borderRadius: '50%',
                  background: `hsl(${i * 40 + 200}, 50%, 25%)`,
                  color: `hsl(${i * 40 + 200}, 70%, 75%)`,
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                  fontSize: 11, fontWeight: 600, flexShrink: 0,
                }}>
                  {t.name.split(' ').map(n => n[0]).join('')}
                </div>
                <div style={{ flex: 1 }}>
                  <div style={{ fontWeight: 600, color: '#e2e8f0', fontSize: 13 }}>{t.name}</div>
                  <div style={{ fontSize: 10, color: '#475569' }}>{t.role}</div>
                </div>
                <div style={{ display: 'flex', gap: 6 }}>
                  <span className="team-badge" style={{ background: '#172554', color: '#60a5fa' }}>{t.active}</span>
                  {t.overdue > 0 && (
                    <span className="team-badge" style={{ background: '#450a0a', color: '#f87171' }}>{t.overdue}</span>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Live Feed */}
        <LiveFeed />
      </div>

      {/* Pipeline Kanban */}
      <div className="card" style={{ marginTop: 20 }}>
        <div className="card-header">
          <span className="card-title">Rulemaking Pipeline</span>
          <button onClick={() => navigate('/pipeline')} style={{
            background: 'none', border: 'none', color: '#60a5fa',
            fontSize: 11, cursor: 'pointer', fontFamily: 'var(--font-sans)',
          }}>View full →</button>
        </div>
        <div className="kanban">
          {['drafting', 'proposed', 'comment', 'final'].map(stage => {
            const items = PIPELINE.filter(p => p.stage === stage);
            const s = STAGE_COLORS[stage];
            return (
              <div key={stage} className="kanban-col">
                <div className="kanban-header" style={{ borderBottom: `2px solid ${s.accent}` }}>
                  <span style={{ fontWeight: 700, fontSize: 12, color: s.text }}>{s.label}</span>
                  <span className="kanban-count" style={{ background: s.bg, color: s.text }}>{items.length}</span>
                </div>
                {items.map((p, i) => (
                  <div key={i} className="kanban-card"
                    onMouseEnter={e => { e.currentTarget.style.borderColor = s.accent; e.currentTarget.style.boxShadow = `0 0 20px ${s.accent}15`; }}
                    onMouseLeave={e => { e.currentTarget.style.borderColor = ''; e.currentTarget.style.boxShadow = ''; }}>
                    <div className="kanban-card-title">{p.title}</div>
                    {p.docket && <div className="kanban-card-meta">{p.docket}</div>}
                    {p.comments > 0 && <div className="kanban-card-sub">{p.comments} comments</div>}
                  </div>
                ))}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
