import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { api } from '../api';

export default function Processing() {
  const [rules, setRules] = useState([]);
  const [selectedDocket, setSelectedDocket] = useState('');
  const [running, setRunning] = useState(null);
  const [result, setResult] = useState(null);
  const navigate = useNavigate();

  useEffect(() => {
    api.getRules().then(data => setRules(data.rules || data || [])).catch(() => {});
  }, []);

  const run = async (label, fn) => {
    if (!selectedDocket) return;
    setRunning(label);
    setResult(null);
    try {
      const r = await fn();
      setResult({ ok: true, data: r, label });
    } catch (e) {
      setResult({ ok: false, error: e.message, label });
    }
    setRunning(null);
  };

  const btnStyle = (disabled) => ({
    padding: '12px 20px', borderRadius: 8, fontSize: 13, fontWeight: 600,
    cursor: disabled ? 'not-allowed' : 'pointer', fontFamily: 'var(--font-sans)',
    border: '1px solid #1e293b', transition: 'all 0.15s',
    opacity: disabled ? 0.5 : 1,
  });

  return (
    <div>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 24 }}>
        <div>
          <h2 className="page-title">AI Processing</h2>
          <p className="page-desc">Run analysis pipelines on comment dockets</p>
        </div>
        <button onClick={() => navigate('/comments')} style={{
          background: 'none', border: '1px solid #1e293b', color: '#64748b',
          padding: '6px 14px', borderRadius: 6, fontSize: 12, cursor: 'pointer', fontFamily: 'var(--font-sans)',
        }}>← Back to Dashboard</button>
      </div>

      <div className="card" style={{ marginBottom: 20 }}>
        <label style={{ fontSize: 12, fontWeight: 600, color: '#94a3b8', display: 'block', marginBottom: 8 }}>
          Select Docket
        </label>
        <select value={selectedDocket} onChange={e => setSelectedDocket(e.target.value)} style={{
          width: '100%', padding: '10px 14px', borderRadius: 8,
          background: '#0f172a', border: '1px solid #1e293b', color: '#e2e8f0', fontSize: 13,
        }}>
          <option value="">— Select a docket —</option>
          {rules.map(r => (
            <option key={r.docket_number} value={r.docket_number}>
              {r.docket_number} — {r.title}
            </option>
          ))}
        </select>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 16, marginBottom: 20 }}>
        <div className="card" style={{ textAlign: 'center' }}>
          <div style={{ fontSize: 24, marginBottom: 8 }}>📋</div>
          <div style={{ fontWeight: 600, color: '#e2e8f0', marginBottom: 4 }}>Form Letter Detection</div>
          <div style={{ fontSize: 11, color: '#64748b', marginBottom: 16 }}>Group identical/near-identical submissions</div>
          <button
            onClick={() => run('Form Letters', () => api.detectFormLetters(selectedDocket))}
            disabled={!selectedDocket || running}
            style={{ ...btnStyle(!selectedDocket || running), background: '#172554', color: '#60a5fa' }}
          >{running === 'Form Letters' ? 'Running...' : 'Detect'}</button>
        </div>

        <div className="card" style={{ textAlign: 'center' }}>
          <div style={{ fontSize: 24, marginBottom: 8 }}>🏷️</div>
          <div style={{ fontWeight: 600, color: '#e2e8f0', marginBottom: 4 }}>AI Tiering</div>
          <div style={{ fontSize: 11, color: '#64748b', marginBottom: 16 }}>Classify comments into Tier 1/2/3</div>
          <button
            onClick={() => run('Tiering', () => api.aiTier(selectedDocket, 100))}
            disabled={!selectedDocket || running}
            style={{ ...btnStyle(!selectedDocket || running), background: '#2e1065', color: '#a78bfa' }}
          >{running === 'Tiering' ? 'Running...' : 'Tier'}</button>
        </div>

        <div className="card" style={{ textAlign: 'center' }}>
          <div style={{ fontSize: 24, marginBottom: 8 }}>🧠</div>
          <div style={{ fontWeight: 600, color: '#e2e8f0', marginBottom: 4 }}>AI Summarization</div>
          <div style={{ fontSize: 11, color: '#64748b', marginBottom: 16 }}>Generate structured summaries</div>
          <div style={{ display: 'flex', gap: 8, justifyContent: 'center' }}>
            {[1, 2, 3].map(t => (
              <button key={t}
                onClick={() => run(`Tier ${t}`, () => api.aiSummarize(selectedDocket, t, 100))}
                disabled={!selectedDocket || running}
                style={{ ...btnStyle(!selectedDocket || running), background: '#14532d', color: '#4ade80', padding: '8px 14px', fontSize: 11 }}
              >{running === `Tier ${t}` ? '...' : `Tier ${t}`}</button>
            ))}
          </div>
        </div>
      </div>

      {result && (
        <div className="card" style={{
          borderColor: result.ok ? '#166534' : '#7f1d1d',
        }}>
          <div style={{ fontWeight: 600, color: result.ok ? '#4ade80' : '#f87171', marginBottom: 8 }}>
            {result.ok ? `✓ ${result.label} complete` : `✗ ${result.label} failed`}
          </div>
          <pre style={{ fontSize: 11, color: '#94a3b8', whiteSpace: 'pre-wrap', fontFamily: 'var(--font-mono)' }}>
            {result.ok ? JSON.stringify(result.data, null, 2) : result.error}
          </pre>
        </div>
      )}
    </div>
  );
}
