import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { api } from '../api';

export default function NewDocket() {
  const [year, setYear] = useState(2025);
  const [releases, setReleases] = useState([]);
  const [loading, setLoading] = useState(false);
  const [ingesting, setIngesting] = useState(null);
  const [result, setResult] = useState(null);
  const navigate = useNavigate();

  const browse = async () => {
    setLoading(true);
    try {
      const data = await api.getRulemakings(year);
      setReleases(data.releases || data || []);
    } catch (e) {
      setResult({ ok: false, error: e.message });
    }
    setLoading(false);
  };

  const ingest = async (releaseId) => {
    setIngesting(releaseId);
    setResult(null);
    try {
      const r = await api.ingestDocket(releaseId);
      setResult({ ok: true, data: r });
    } catch (e) {
      setResult({ ok: false, error: e.message });
    }
    setIngesting(null);
  };

  return (
    <div>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 24 }}>
        <div>
          <h2 className="page-title">New Docket</h2>
          <p className="page-desc">Browse CFTC releases and ingest comment dockets</p>
        </div>
        <button onClick={() => navigate('/comments')} style={{
          background: 'none', border: '1px solid #1e293b', color: '#64748b',
          padding: '6px 14px', borderRadius: 6, fontSize: 12, cursor: 'pointer', fontFamily: 'var(--font-sans)',
        }}>← Back</button>
      </div>

      <div className="card" style={{ display: 'flex', gap: 12, alignItems: 'center', marginBottom: 20 }}>
        <select value={year} onChange={e => setYear(parseInt(e.target.value))} style={{
          padding: '10px 14px', borderRadius: 8, background: '#0f172a',
          border: '1px solid #1e293b', color: '#e2e8f0', fontSize: 13,
        }}>
          {[2025, 2024, 2023, 2022, 2021, 2020].map(y => (
            <option key={y} value={y}>{y}</option>
          ))}
        </select>
        <button onClick={browse} disabled={loading} style={{
          padding: '10px 20px', borderRadius: 8, background: '#172554', color: '#60a5fa',
          border: '1px solid #1e3a5f', fontSize: 13, fontWeight: 600, cursor: 'pointer',
          fontFamily: 'var(--font-sans)', opacity: loading ? 0.5 : 1,
        }}>{loading ? 'Loading...' : 'Browse Releases'}</button>
      </div>

      {releases.length > 0 && (
        <div className="card" style={{ padding: 0, overflow: 'hidden' }}>
          <table className="data-table">
            <thead>
              <tr>
                <th>Release ID</th>
                <th>Title</th>
                <th>Comments</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody>
              {releases.map((r, i) => (
                <tr key={i}>
                  <td style={{ fontFamily: 'var(--font-mono)', color: '#94a3b8' }}>{r.release_id || r.id}</td>
                  <td style={{ color: '#e2e8f0', maxWidth: 400 }}>{r.title}</td>
                  <td style={{ color: '#64748b' }}>{r.comment_count || '—'}</td>
                  <td>
                    <button
                      onClick={() => ingest(r.release_id || r.id)}
                      disabled={ingesting}
                      style={{
                        padding: '4px 12px', borderRadius: 4, background: '#14532d',
                        color: '#4ade80', border: '1px solid #166534', fontSize: 11,
                        fontWeight: 600, cursor: 'pointer', opacity: ingesting ? 0.5 : 1,
                      }}
                    >{ingesting === (r.release_id || r.id) ? 'Ingesting...' : 'Ingest'}</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {result && (
        <div className="card" style={{ marginTop: 16, borderColor: result.ok ? '#166534' : '#7f1d1d' }}>
          <div style={{ fontWeight: 600, color: result.ok ? '#4ade80' : '#f87171' }}>
            {result.ok ? '✓ Docket ingested successfully' : `✗ ${result.error}`}
          </div>
        </div>
      )}
    </div>
  );
}
