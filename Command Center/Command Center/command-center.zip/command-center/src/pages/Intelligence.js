import React from 'react';
import { Pulse, FEED_COLORS } from '../components/UI';

const FEED = [
  { time: '2 min ago', type: 'tweet', source: '@CFTCChairman', text: 'Excited to announce progress on our digital assets framework. The PWG report is ahead of schedule.', icon: '𝕏' },
  { time: '18 min ago', type: 'news', source: 'Reuters', text: 'SEC and CFTC to hold joint hearing on crypto custody rules next month', icon: '◆' },
  { time: '34 min ago', type: 'fr', source: 'Federal Register', text: 'CFTC-2025-0005: Digital Asset Clearing Amendments — 12 new comments received', icon: '⬢' },
  { time: '1 hr ago', type: 'tweet', source: '@SenLummis', text: 'Bipartisan stablecoin bill moves to markup next week. Strong support from Treasury and CFTC.', icon: '𝕏' },
  { time: '1.5 hr ago', type: 'news', source: 'CoinDesk', text: 'Kalshi seeks to expand political event contracts after favorable CFTC guidance', icon: '◆' },
  { time: '2 hr ago', type: 'regulatory', source: 'SEC', text: 'Staff Accounting Bulletin 122 rescission — crypto custody treatment revised', icon: '⊕' },
  { time: '3 hr ago', type: 'tweet', source: '@HesterPeirce', text: 'Tokenized collateral is the next frontier. Looking forward to CFTC\'s proposed framework.', icon: '𝕏' },
  { time: '4 hr ago', type: 'fr', source: 'Federal Register', text: 'OCC issues interpretive letter on national bank authority for stablecoin reserves', icon: '⬢' },
  { time: '5 hr ago', type: 'news', source: 'Bloomberg', text: 'Trump crypto working group targets July deadline for comprehensive regulatory framework', icon: '◆' },
  { time: '6 hr ago', type: 'regulatory', source: 'Treasury', text: 'FinCEN proposed rule on DeFi broker definition — comment period opens March 1', icon: '⊕' },
];

export default function Intelligence() {
  const tweets = FEED.filter(f => f.type === 'tweet');
  const other = FEED.filter(f => f.type !== 'tweet');

  return (
    <div>
      <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 24 }}>
        <h2 className="page-title">Intelligence</h2>
        <Pulse color="#22c55e" />
        <span style={{ fontSize: 11, color: '#475569' }}>Real-time</span>
      </div>

      <div className="grid-2" style={{ marginBottom: 24 }}>
        {[
          { label: 'Tweets tracked', value: '24', sub: 'Last 24 hrs', accent: '#1d9bf0' },
          { label: 'News articles', value: '12', sub: 'Last 24 hrs', accent: '#f59e0b' },
          { label: 'FR entries', value: '3', sub: 'Today', accent: '#a78bfa' },
          { label: 'Regulatory actions', value: '7', sub: 'This week', accent: '#34d399' },
        ].map((s, i) => (
          <div key={i} className="card" style={{ display: 'flex', alignItems: 'center', gap: 16, padding: '16px 20px' }}>
            <div style={{
              width: 40, height: 40, borderRadius: 10,
              background: `${s.accent}15`, border: `1px solid ${s.accent}30`,
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              fontSize: 18, fontWeight: 700, color: s.accent,
            }}>{s.value}</div>
            <div>
              <div style={{ fontSize: 13, fontWeight: 600, color: '#e2e8f0' }}>{s.label}</div>
              <div style={{ fontSize: 11, color: '#475569' }}>{s.sub}</div>
            </div>
          </div>
        ))}
      </div>

      <div className="grid-2">
        <div className="card">
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 14 }}>
            <span style={{ color: '#1d9bf0', fontSize: 16, fontWeight: 700 }}>𝕏</span>
            <span className="card-title">Tracked Accounts</span>
          </div>
          {tweets.map((f, i) => (
            <div key={i} style={{ padding: '12px 0', borderBottom: '1px solid var(--border)', cursor: 'pointer' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 4 }}>
                <span style={{ fontSize: 12, fontWeight: 600, color: '#1d9bf0' }}>{f.source}</span>
                <span style={{ fontSize: 10, color: '#475569' }}>{f.time}</span>
              </div>
              <div className="feed-text">{f.text}</div>
            </div>
          ))}
        </div>

        <div className="card">
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 14 }}>
            <span style={{ color: '#f59e0b', fontSize: 14 }}>◆</span>
            <span className="card-title">News & Regulatory</span>
          </div>
          {other.map((f, i) => {
            const fc = FEED_COLORS[f.type] || FEED_COLORS.news;
            return (
              <div key={i} style={{ padding: '12px 0', borderBottom: '1px solid var(--border)', cursor: 'pointer' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginBottom: 4 }}>
                  <span style={{ fontSize: 10, color: fc.accent, fontWeight: 700 }}>{f.icon}</span>
                  <span style={{ fontSize: 11, fontWeight: 600, color: fc.accent }}>{f.source}</span>
                  <span style={{ fontSize: 10, color: '#475569', marginLeft: 'auto' }}>{f.time}</span>
                </div>
                <div className="feed-text">{f.text}</div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
