import React from 'react';
import { STAGE_COLORS } from '../components/UI';

const PIPELINE = [
  { title: 'Event Contracts & Enumerated Activities', stage: 'comment', docket: 'CFTC-2024-0007', comments: 819, deadline: '2025-04-30' },
  { title: 'Tokenized Collateral Framework', stage: 'proposed', docket: 'CFTC-2025-0002', comments: 0, deadline: '2025-06-15' },
  { title: 'DeFi Safe Harbor Pilot', stage: 'drafting', docket: null, comments: 0, deadline: '2025-08-01' },
  { title: 'Digital Asset Clearing Amendments', stage: 'proposed', docket: 'CFTC-2025-0005', comments: 42, deadline: '2025-05-20' },
  { title: 'Reg AT Modernization', stage: 'final', docket: 'CFTC-2024-0012', comments: 156, deadline: '2025-03-15' },
];

export default function Pipeline() {
  return (
    <div>
      <h2 className="page-title" style={{ marginBottom: 24 }}>Rulemaking Pipeline</h2>
      <div className="kanban" style={{ gap: 16 }}>
        {['drafting', 'proposed', 'comment', 'final'].map(stage => {
          const items = PIPELINE.filter(p => p.stage === stage);
          const s = STAGE_COLORS[stage];
          return (
            <div key={stage} className="kanban-col">
              <div className="kanban-header" style={{ borderBottom: `2px solid ${s.accent}`, paddingBottom: 12, marginBottom: 14 }}>
                <span style={{ fontWeight: 700, fontSize: 13, color: s.text }}>{s.label}</span>
                <span className="kanban-count" style={{ background: s.bg, color: s.text, width: 22, height: 22, fontSize: 11 }}>
                  {items.length}
                </span>
              </div>
              {items.map((p, i) => (
                <div key={i} className="kanban-card" style={{ padding: 16, marginBottom: 10 }}
                  onMouseEnter={e => { e.currentTarget.style.borderColor = s.accent; e.currentTarget.style.boxShadow = `0 0 20px ${s.accent}15`; }}
                  onMouseLeave={e => { e.currentTarget.style.borderColor = ''; e.currentTarget.style.boxShadow = ''; }}>
                  <div style={{ fontWeight: 600, fontSize: 13, color: '#e2e8f0', marginBottom: 6 }}>{p.title}</div>
                  {p.docket && <div style={{ fontSize: 10, color: '#475569', fontFamily: 'var(--font-mono)', marginBottom: 4 }}>{p.docket}</div>}
                  {p.comments > 0 && <div style={{ fontSize: 10, color: '#64748b' }}>{p.comments} comments</div>}
                  {p.deadline && <div style={{ fontSize: 10, color: '#64748b', marginTop: 4 }}>Due: {p.deadline}</div>}
                </div>
              ))}
            </div>
          );
        })}
      </div>
    </div>
  );
}
