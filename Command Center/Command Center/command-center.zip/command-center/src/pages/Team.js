import React from 'react';

const TEAM = [
  { name: 'Sarah Chen', role: 'Assistant General Counsel', gs: 'GS-15', active: 3, overdue: 1 },
  { name: 'Marcus Williams', role: 'Senior Counsel', gs: 'GS-15', active: 4, overdue: 0 },
  { name: 'Jennifer Park', role: 'Senior Counsel', gs: 'GS-14', active: 2, overdue: 0 },
  { name: 'David Thompson', role: 'Attorney-Adviser', gs: 'GS-14', active: 3, overdue: 1 },
  { name: 'Rachel Foster', role: 'Attorney-Adviser', gs: 'GS-13', active: 2, overdue: 0 },
  { name: 'James Liu', role: 'Attorney-Adviser', gs: 'GS-13', active: 1, overdue: 0 },
  { name: 'Ana Martinez', role: 'Attorney-Adviser', gs: 'GS-13', active: 3, overdue: 2 },
  { name: 'Robert Kim', role: 'Attorney-Adviser', gs: 'GS-12', active: 2, overdue: 0 },
  { name: 'Lisa Patel', role: 'Attorney-Adviser', gs: 'GS-12', active: 1, overdue: 0 },
  { name: 'Michael Brown', role: 'Attorney-Adviser', gs: 'GS-12', active: 2, overdue: 1 },
];

export default function Team() {
  return (
    <div>
      <h2 className="page-title" style={{ marginBottom: 24 }}>Team — Regulation Division</h2>
      <div className="grid-2" style={{ gap: 14 }}>
        {TEAM.map((t, i) => (
          <div key={i} className="team-card">
            <div className="team-avatar" style={{
              background: `hsl(${i * 36 + 200}, 45%, 22%)`,
              color: `hsl(${i * 36 + 200}, 65%, 72%)`,
            }}>
              {t.name.split(' ').map(n => n[0]).join('')}
            </div>
            <div style={{ flex: 1 }}>
              <div className="team-name">{t.name}</div>
              <div className="team-role">{t.role} · {t.gs}</div>
              <div className="team-badges">
                <span className="team-badge" style={{ background: '#172554', color: '#60a5fa' }}>{t.active} active</span>
                {t.overdue > 0 && (
                  <span className="team-badge" style={{ background: '#450a0a', color: '#f87171' }}>{t.overdue} overdue</span>
                )}
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
