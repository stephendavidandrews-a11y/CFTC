import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { PieChart, Pie, Cell, Tooltip, ResponsiveContainer, BarChart, Bar, XAxis, YAxis } from 'recharts';
import { api } from '../api';

const COLORS_TIER = ['#3b82f6', '#a78bfa', '#64748b'];
const COLORS_SENTIMENT = ['#ef4444', '#22c55e', '#f59e0b', '#64748b'];

export default function CommentsDashboard() {
  const [rules, setRules] = useState([]);
  const [selectedDocket, setSelectedDocket] = useState('');
  const [stats, setStats] = useState(null);
  const [narrative, setNarrative] = useState(null);
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    api.getRules().then(data => {
      const r = data.rules || data || [];
      setRules(r);
    }).catch(() => {});
  }, []);

  useEffect(() => {
    if (!selectedDocket) { setStats(null); setNarrative(null); return; }
    setLoading(true);
    Promise.all([
      api.getStats(selectedDocket),
      api.getNarrative(selectedDocket).catch(() => ({ narrative: null })),
    ]).then(([s, n]) => {
      setStats(s);
      setNarrative(n.narrative);
    }).finally(() => setLoading(false));
  }, [selectedDocket]);

  const tierData = stats ? [
    { name: 'Tier 1', value: stats.tier_counts?.['1'] || 0 },
    { name: 'Tier 2', value: stats.tier_counts?.['2'] || 0 },
    { name: 'Tier 3', value: stats.tier_counts?.['3'] || 0 },
  ] : [];

  const sentimentData = stats ? [
    { name: 'Oppose', value: stats.sentiment_counts?.oppose || 0 },
    { name: 'Support', value: stats.sentiment_counts?.support || 0 },
    { name: 'Mixed', value: stats.sentiment_counts?.mixed || 0 },
    { name: 'Neutral', value: stats.sentiment_counts?.neutral || 0 },
  ] : [];

  return (
    <div>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 24 }}>
        <div>
          <h2 className="page-title">Comment Analyzer</h2>
          <p className="page-desc">AI-powered public comment analysis system</p>
        </div>
        <div style={{ display: 'flex', gap: 8 }}>
          <button onClick={() => navigate('/comments/browse')} style={{
            background: '#172554', color: '#60a5fa', border: '1px solid #1e3a5f',
            padding: '8px 16px', borderRadius: 6, fontSize: 12, fontWeight: 600,
            cursor: 'pointer', fontFamily: 'var(--font-sans)',
          }}>Browse Comments</button>
          <button onClick={() => navigate('/comments/processing')} style={{
            background: '#1f2937', color: '#94a3b8', border: '1px solid #374151',
            padding: '8px 16px', borderRadius: 6, fontSize: 12, fontWeight: 600,
            cursor: 'pointer', fontFamily: 'var(--font-sans)',
          }}>AI Processing</button>
          <button onClick={() => navigate('/comments/new-docket')} style={{
            background: '#14532d', color: '#4ade80', border: '1px solid #166534',
            padding: '8px 16px', borderRadius: 6, fontSize: 12, fontWeight: 600,
            cursor: 'pointer', fontFamily: 'var(--font-sans)',
          }}>+ New Docket</button>
        </div>
      </div>

      {/* Docket selector */}
      <div className="card" style={{ marginBottom: 20 }}>
        <label style={{ fontSize: 12, fontWeight: 600, color: '#94a3b8', display: 'block', marginBottom: 8 }}>
          Select Docket
        </label>
        <select
          value={selectedDocket}
          onChange={e => setSelectedDocket(e.target.value)}
          style={{
            width: '100%', padding: '10px 14px', borderRadius: 8,
            background: '#0f172a', border: '1px solid #1e293b', color: '#e2e8f0',
            fontSize: 13, fontFamily: 'var(--font-sans)', cursor: 'pointer',
          }}
        >
          <option value="">— Select a docket to view analysis —</option>
          {rules.map(r => (
            <option key={r.docket_number} value={r.docket_number}>
              {r.docket_number} — {r.title} ({r.comment_count} comments)
            </option>
          ))}
        </select>
      </div>

      {loading && (
        <div style={{ textAlign: 'center', padding: 40, color: '#64748b' }}>Loading analysis...</div>
      )}

      {stats && !loading && (
        <>
          {/* Stats row */}
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 14, marginBottom: 20 }}>
            {[
              { v: stats.total_comments, l: 'Total Comments', c: 'blue' },
              { v: stats.tier_counts?.['1'] || 0, l: 'Tier 1 (Institutional)', c: 'purple' },
              { v: stats.form_letter_count || 0, l: 'Form Letters', c: 'green' },
              { v: `${stats.sentiment_counts?.oppose || 0}/${stats.sentiment_counts?.support || 0}`, l: 'Oppose / Support', c: 'red' },
            ].map((s, i) => (
              <div key={i} className={`stat-card ${s.c}`}>
                <div className="stat-value">{s.v}</div>
                <div className="stat-label">{s.l}</div>
              </div>
            ))}
          </div>

          {/* Charts */}
          <div className="grid-2" style={{ marginBottom: 20 }}>
            <div className="card">
              <div className="card-title" style={{ marginBottom: 16 }}>Comment Tiers</div>
              <ResponsiveContainer width="100%" height={200}>
                <PieChart>
                  <Pie data={tierData} cx="50%" cy="50%" innerRadius={50} outerRadius={80} dataKey="value" label={({ name, value }) => `${name}: ${value}`}>
                    {tierData.map((_, i) => <Cell key={i} fill={COLORS_TIER[i]} />)}
                  </Pie>
                  <Tooltip contentStyle={{ background: '#1e293b', border: '1px solid #334155', borderRadius: 8, color: '#e2e8f0' }} />
                </PieChart>
              </ResponsiveContainer>
            </div>
            <div className="card">
              <div className="card-title" style={{ marginBottom: 16 }}>Sentiment</div>
              <ResponsiveContainer width="100%" height={200}>
                <BarChart data={sentimentData}>
                  <XAxis dataKey="name" tick={{ fill: '#64748b', fontSize: 11 }} axisLine={{ stroke: '#1e293b' }} />
                  <YAxis tick={{ fill: '#64748b', fontSize: 11 }} axisLine={{ stroke: '#1e293b' }} />
                  <Bar dataKey="value" radius={[4, 4, 0, 0]}>
                    {sentimentData.map((_, i) => <Cell key={i} fill={COLORS_SENTIMENT[i]} />)}
                  </Bar>
                  <Tooltip contentStyle={{ background: '#1e293b', border: '1px solid #334155', borderRadius: 8, color: '#e2e8f0' }} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Narrative */}
          {narrative && (
            <div className="card" style={{ marginBottom: 20 }}>
              <div className="card-title" style={{ marginBottom: 12 }}>AI Narrative Synthesis</div>
              <div style={{ fontSize: 13, color: '#cbd5e1', lineHeight: 1.7, whiteSpace: 'pre-wrap' }}>{narrative}</div>
            </div>
          )}

          {/* Export buttons */}
          <div className="card" style={{ display: 'flex', gap: 12 }}>
            <a href={api.exportBriefing(selectedDocket)} target="_blank" rel="noreferrer" style={{
              padding: '10px 20px', borderRadius: 6, background: '#172554', color: '#60a5fa',
              border: '1px solid #1e3a5f', textDecoration: 'none', fontSize: 12, fontWeight: 600,
            }}>Export Briefing Doc</a>
            <a href={api.exportPdfs(selectedDocket)} target="_blank" rel="noreferrer" style={{
              padding: '10px 20px', borderRadius: 6, background: '#1f2937', color: '#94a3b8',
              border: '1px solid #374151', textDecoration: 'none', fontSize: 12, fontWeight: 600,
            }}>Download PDFs</a>
          </div>
        </>
      )}
    </div>
  );
}
