import React from 'react';

export default function Placeholder({ title, description, icon }) {
  return (
    <div>
      <h2 className="page-title" style={{ marginBottom: 8 }}>{title}</h2>
      <p className="page-desc" style={{ marginBottom: 24 }}>{description}</p>
      <div className="placeholder-box">
        <div className="placeholder-icon">{icon}</div>
        <div className="placeholder-title">Coming Soon</div>
        <div className="placeholder-sub">This module will connect to your data pipeline</div>
      </div>
    </div>
  );
}
