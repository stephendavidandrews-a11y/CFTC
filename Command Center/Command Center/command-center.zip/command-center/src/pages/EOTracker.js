import React from 'react';
import { Badge, STATUS_COLORS } from '../components/UI';

const EO_DATA = [
  { number: '14178', title: 'Strengthening American Leadership in Digital Financial Technology', status: 'in_progress', deadline: '2025-04-15', actions: 6, completed: 2 },
  { number: '14067', title: 'Ensuring Responsible Development of Digital Assets', status: 'superseded', deadline: null, actions: 4, completed: 4 },
  { number: '14192', title: 'Unleashing Prosperity Through Deregulation', status: 'in_progress', deadline: '2025-05-01', actions: 3, completed: 0 },
  { number: '14148', title: 'Initial Rescissions of Harmful EOs and Actions', status: 'completed', deadline: null, actions: 2, completed: 2 },
  { number: '14219', title: 'Establishing the Presidential Working Group on Digital Asset Markets', status: 'in_progress', deadline: '2025-07-22', actions: 8, completed: 3 },
];

export default function EOTracker() {
  return (
    <div>
      <h2 className="page-title" style={{ marginBottom: 24 }}>Executive Order Tracker</h2>
      <div className="card" style={{ padding: 0, overflow: 'hidden' }}>
        <table className="data-table">
          <thead>
            <tr>
              {['EO #', 'Title', 'Status', 'Deadline', 'Actions', 'Progress'].map(h => (
                <th key={h}>{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {EO_DATA.map((eo, i) => {
              const s = STATUS_COLORS[eo.status];
              const pct = Math.round((eo.completed / eo.actions) * 100);
              return (
                <tr key={i}>
                  <td style={{ fontWeight: 700, fontFamily: 'var(--font-mono)', color: '#94a3b8' }}>{eo.number}</td>
                  <td style={{ fontWeight: 500, color: '#e2e8f0', maxWidth: 300 }}>{eo.title}</td>
                  <td><Badge bg={s.bg} text={s.text} label={s.label} /></td>
                  <td style={{ color: '#64748b', fontFamily: 'var(--font-mono)', fontSize: 12 }}>{eo.deadline || '—'}</td>
                  <td>
                    <span style={{ fontWeight: 700, color: '#e2e8f0' }}>{eo.completed}</span>
                    <span style={{ color: '#475569' }}> / {eo.actions}</span>
                  </td>
                  <td style={{ width: 140 }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                      <div className="progress-bar">
                        <div className="progress-fill" style={{
                          width: `${pct}%`,
                          background: pct === 100 ? '#22c55e' : '#3b82f6',
                        }} />
                      </div>
                      <span style={{ fontSize: 10, color: '#64748b', width: 30, textAlign: 'right' }}>{pct}%</span>
                    </div>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
}
